import os
import uuid
import asyncio
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, HTTPException
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import AzureError
import grpc
import document_service_pb2
import document_service_pb2_grpc
load_dotenv()
AZURE_ENDPOINT = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
AZURE_KEY = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
if not AZURE_ENDPOINT or not AZURE_KEY:
    raise RuntimeError("Azure Document Intelligence configuration is missing.")
app = FastAPI(
    title="Document Intelligence API",
    description="Web API for extracting text from documents using Azure AI Document Intelligence."
)
document_client = DocumentIntelligenceClient(
    endpoint=AZURE_ENDPOINT,
    credential=AzureKeyCredential(AZURE_KEY)
)
jobs = {}
job_queue = asyncio.Queue()
grpc_channel = grpc.insecure_channel("localhost:50051")
grpc_client = document_service_pb2_grpc.DocumentProcessorStub(
    grpc_channel
)
@app.get("/")
def home():
    return {
        "message": "Document Intelligence API is running"
    }
@app.post("/analyze")
async def analyze_document(file: UploadFile = File(...)):
    allowed_types = [
        "application/pdf",
        "image/jpeg",
        "image/png"
    ]
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Use PDF, JPG, or PNG."
        )
    document = await file.read()
    if not document:
        raise HTTPException(
            status_code=400,
            detail="The uploaded file is empty."
        )
    try:
        poller = document_client.begin_analyze_document(
            "prebuilt-read",
            body=document
        )
        result = poller.result()
        return {
            "filename": file.filename,
            "text": result.content
        }
    except AzureError as error:
        raise HTTPException(
            status_code=500,
            detail=f"Azure Document Intelligence error: {str(error)}"
        )
@app.post("/jobs")
async def create_job(file: UploadFile = File(...)):
    allowed_types = [
        "application/pdf",
        "image/jpeg",
        "image/png"
    ]
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Use PDF, JPG, or PNG."
        )
    document = await file.read()
    if not document:
        raise HTTPException(
            status_code=400,
            detail="The uploaded file is empty."
        )
    request_id = str(uuid.uuid4())
    jobs[request_id] = {
        "filename": file.filename,
        "status": "waiting",
        "result": None,
        "error": None
    }
    await job_queue.put({
        "request_id": request_id,
        "document": document
    })
    return {
        "request_id": request_id,
        "status": "waiting"
    }
@app.get("/jobs/{request_id}")
def get_job(request_id: str):
    if request_id not in jobs:
        raise HTTPException(
            status_code=404,
            detail="Job not found."
        )
    job = jobs[request_id]
    return {
        "request_id": request_id,
        "filename": job["filename"],
        "status": job["status"],
        "result": job["result"],
        "error": job["error"]
    }
async def process_jobs():
    while True:
        job_data = await job_queue.get()
        request_id = job_data["request_id"]
        document = job_data["document"]
        jobs[request_id]["status"] = "processing"
        try:
            grpc_request = document_service_pb2.DocumentRequest(
                request_id=request_id,
                document=document
            )
            grpc_response = await asyncio.to_thread(
                grpc_client.AnalyzeDocument,
                grpc_request
            )
            jobs[request_id]["status"] = grpc_response.status
            if grpc_response.status == "completed":
                jobs[request_id]["result"] = grpc_response.extracted_text
            else:
                jobs[request_id]["error"] = grpc_response.error
        except grpc.RpcError as error:
            jobs[request_id]["status"] = "failed"
            jobs[request_id]["error"] = str(error)
        finally:
            job_queue.task_done()
        await asyncio.sleep(30)
@app.on_event("startup")
async def startup_event():
    asyncio.create_task(process_jobs())