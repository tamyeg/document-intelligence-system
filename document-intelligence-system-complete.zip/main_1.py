import os
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, HTTPException
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import AzureError
load_dotenv()
AZURE_ENDPOINT = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
AZURE_KEY = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
if not AZURE_ENDPOINT or not AZURE_KEY:
    raise RuntimeError("Azure Document Intelligence configuration is missing.")
app = FastAPI(
    title="Document Intelligence API",
    description="Web API for extracting text from documents using Azure AI Document Intelligence."
)
document_client = DocumentIntelligenceClient(
    endpoint=AZURE_ENDPOINT,
    credential=AzureKeyCredential(AZURE_KEY)
)
@app.get("/")
def home():
    return {
        "message": "Document Intelligence API is running"
    }
@app.post("/analyze")
async def analyze_document(file: UploadFile = File(...)):
    allowed_types = [
        "application/pdf",
        "image/jpeg",
        "image/png"
    ]
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Use PDF, JPG, or PNG."
        )
    document = await file.read()
    if not document:
        raise HTTPException(
            status_code=400,
            detail="The uploaded file is empty."
        )
    try:
        poller = document_client.begin_analyze_document(
            "prebuilt-read",
            body=document
        )
        result = poller.result()
        return {
            "filename": file.filename,
            "text": result.content
        }
    except AzureError as error:
        raise HTTPException(
            status_code=500,
            detail=f"Azure Document Intelligence error: {str(error)}"
        )