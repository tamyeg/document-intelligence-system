import os
from concurrent import futures
import grpc
from dotenv import load_dotenv
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
import document_service_pb2
import document_service_pb2_grpc
load_dotenv()
AZURE_ENDPOINT = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
AZURE_KEY = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
document_client = DocumentIntelligenceClient(
    endpoint=AZURE_ENDPOINT,
    credential=AzureKeyCredential(AZURE_KEY)
)
class DocumentProcessorService(
    document_service_pb2_grpc.DocumentProcessorServicer
):
    def AnalyzeDocument(self, request, context):
        try:
            poller = document_client.begin_analyze_document(
                "prebuilt-read",
                body=request.document
            )
            result = poller.result()
            return document_service_pb2.DocumentResponse(
                request_id=request.request_id,
                extracted_text=result.content,
                status="completed",
                error=""
            )
        except Exception as error:
            return document_service_pb2.DocumentResponse(
                request_id=request.request_id,
                extracted_text="",
                status="failed",
                error=str(error)
            )
def serve():
    server = grpc.server(
        futures.ThreadPoolExecutor(max_workers=10)
    )
    document_service_pb2_grpc.add_DocumentProcessorServicer_to_server(
        DocumentProcessorService(),
        server
    )
    server.add_insecure_port("[::]:50051")
    server.start()
    print("gRPC Document Processing Service is running on port 50051")
    server.wait_for_termination()
if __name__ == "__main__":
    serve()