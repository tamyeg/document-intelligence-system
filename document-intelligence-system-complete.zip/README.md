# Document Intelligence System

**Python · FastAPI · gRPC · Azure AI Document Intelligence · Async Job Queue**

## Overview

A document text-extraction application with a REST API, a gRPC processing service, and an in-memory asynchronous job queue. It accepts PDF, JPG, and PNG uploads and uses Azure AI Document Intelligence's `prebuilt-read` model to extract text.

This repository contains both an initial REST-only implementation (`main_1.py`) and a later implementation (`main.py`) that adds queued jobs and gRPC integration.

## Architecture

```text
                              ┌─────────── REST /analyze ──────► Azure AI Document Intelligence
Client ──► FastAPI (main.py) ──┤
                              └─ REST POST /jobs ─► asyncio.Queue ─► worker ─► gRPC :50051
                                      ▲                                  │         │
                                      │                                  │         ▼
                               GET /jobs/{id} ◄── in-memory status ◄─────┘  grpc_server.py
                                                                                  │
                                                                                  ▼
                                                                        Azure AI Document Intelligence
```

`POST /analyze` extracts text directly. `POST /jobs` queues a document and returns a request ID; a background worker sends it to the gRPC service and stores the result for polling.

## API routes

| Method | Route | Description |
|---|---|---|
| `GET` | `/` | API welcome/health message |
| `POST` | `/analyze` | Upload PDF/JPG/PNG and return extracted text synchronously |
| `POST` | `/jobs` | Upload document and create an asynchronous extraction job |
| `GET` | `/jobs/{request_id}` | Retrieve a job's status, result, or error |

Job statuses include `waiting`, `processing`, `completed`, and `failed`. `main_1.py` only implements `/` and `/analyze`.

## File guide

| File | Purpose |
|---|---|
| `main.py` | REST API, queue, in-memory jobs, gRPC client and background worker |
| `main_1.py` | Earlier, direct REST-only API |
| `grpc_server.py` | gRPC document processor (port 50051) |
| `document_service.proto` | `DocumentProcessor.AnalyzeDocument` interface and message schema |
| `document_service_pb2.py`, `document_service_pb2_grpc.py` | Generated protobuf/gRPC Python code |
| `requirements.txt` | Python dependencies |
| `.env.example` | Environment variable template (no credentials) |

## Run locally

**Requirements:** Python, an Azure AI Document Intelligence resource with its endpoint and key, and network access to Azure.

1. Clone the repository and enter its directory.

   ```bash
   git clone https://github.com/tamyeg/document-intelligence-system.git
   cd document-intelligence-system
   ```

2. Create a virtual environment and install dependencies.

   ```bash
   python -m venv .venv
   # Windows PowerShell:
   .venv\Scripts\Activate.ps1
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   ```

3. Copy `.env.example` to `.env` and set `AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT` and `AZURE_DOCUMENT_INTELLIGENCE_KEY` to your own values. **Never commit `.env`.**

4. In one terminal, start the gRPC server:

   ```bash
   python grpc_server.py
   ```

5. In another terminal (same environment and folder), start FastAPI:

   ```bash
   uvicorn main:app --reload
   ```

6. Visit `http://127.0.0.1:8000/docs` for interactive API documentation, or test via `curl`:

   ```bash
   curl -F "file=@sample.pdf" http://127.0.0.1:8000/analyze
   curl -F "file=@sample.pdf" http://127.0.0.1:8000/jobs
   curl http://127.0.0.1:8000/jobs/YOUR_REQUEST_ID
   ```

Replace `sample.pdf` with a file you are authorized to process. The queued worker includes a **30-second delay after each job**; results may not be immediate.

### Regenerating gRPC modules (optional)

```bash
python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. document_service.proto
```

## Implementation notes and limitations

- Queue and job records exist **only in memory**; restarting the FastAPI process loses pending jobs and status.
- The worker processes queued jobs sequentially, with a 30-second sleep after each job.
- The gRPC server uses an **insecure, local-development** channel on port `50051`; it should not be exposed publicly without authentication and transport security.
- API file type checks use the uploaded MIME type; production code would need stronger validation and file-size limits.
- Azure processing requires a valid resource and may incur charges.
- The repository does not include Azure Bot Service deployment code or a durable production-grade queue.
- Generated modules are included so the gRPC server can import them; keep them consistent with the `.proto` file.

## Skills demonstrated

Python backend development, REST endpoints, Protocol Buffers, gRPC, asynchronous task handling, document text extraction, Azure SDK integration, and error handling.

## Author

**Tamara Yegorova** · [GitHub](https://github.com/tamyeg) · [LinkedIn](https://www.linkedin.com/in/tamara-yegorova/)
